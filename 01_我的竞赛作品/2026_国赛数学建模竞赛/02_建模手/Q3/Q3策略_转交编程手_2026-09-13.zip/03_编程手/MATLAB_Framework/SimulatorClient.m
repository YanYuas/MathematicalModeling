% ========================================================================
% SimulatorClient - 模拟器HTTP客户端类
% ========================================================================
% 文件: SimulatorClient.m
% 功能: 封装与模拟器的所有HTTP通信，处理幂等重试、时间跟踪
% 日期: 2026-09-11
% 修改: 2026-09-12 —— 按附件2 §5.3/§12 补三件（**赛题硬要求**）
%       ① 【自记录日志】附件1 §4.6 与附件2 §12 明文「机器狗程序应该自行记录测试过程中的
%          指令序列、响应信息等内容，模拟器没有这一功能」⇒ 本类是全库 4 条指令的**唯一咽喉**，
%          在此落 JSONL，任何调用方自动全覆盖。
%       ② 【双检查】附件2 §5.3「必须同时检查HTTP状态和 accepted，不能只判断其中一个」
%          ⇒ 旧版只判 accepted，且把 accepted=false 当错误**重试 3 次**后 rethrow（会崩）。
%       ③ 【重试口径】附件2 §12/§5.3：**只有网络超时/连接中断**才复用原 request_id 与原内容重试；
%          业务/协议拒绝（accepted=false、HTTP 400/404/405/409/413/415/429/500）**不重试**。
% ========================================================================

classdef SimulatorClient < handle
    properties
        base_url            % 模拟器基础URL
        robot_id            % 机器狗ID（队号）
        request_counter     % 请求计数器
        virtual_time        % 当前虚拟时间 [s]
        remaining_time      % 剩余现实时间 [s]
        timeout             % 单次请求超时 [s]
        max_retries         % 最大重试次数（**仅用于传输层失败**）
        enter_wait_s        % 【新增】/enter 等待接口开放的预算 [s]（倒计时期间接口未开放）
        enter_retry_interval_s  % 【新增】两次 /enter 尝试之间的间隔 [s]
        t_enter_wall        % 【P0-11】/enter 的墙钟计时器句柄（tic）
        elapsed_wall        % 【P0-11】/enter → 现在 的墙钟秒数（表 1 第 4 列用）
        log_dir             % 【新增】日志目录（由本文件位置推导，**不用 cwd 相对路径**）
        log_path            % 【新增】本次会话的日志文件全路径（JSONL）
        log_seq             % 【新增】日志记录序号
    end

    methods
        %% 构造函数
        % 第三个参数可选：覆盖日志目录（仅供离线自测重定向用；正式运行不要传）
        function obj = SimulatorClient(base_url, robot_id, log_dir_override)
            obj.base_url = base_url;
            obj.robot_id = robot_id;
            obj.request_counter = 0;
            obj.virtual_time = 0;
            obj.remaining_time = 1200;  % 初始化为最大值（/enter 成功后会以模拟器返回值为准）
            obj.timeout = 10;
            obj.max_retries = 3;
            obj.enter_wait_s = 90;              % /enter 最多等 90 s（足够覆盖 5 s 倒计时 + 抖动）
            obj.enter_retry_interval_s = 2;     % 每 2 s 试一次
            obj.t_enter_wall = [];
            obj.elapsed_wall = 0;

            % ---- 【新增】日志目录：由**本文件所在目录**推导，不依赖当前工作目录 ----
            % 本项目已踩过"相对 cwd 路径"的坑（见 Q3 SimulatorClient v1.3.1 核验报告 §四.G）
            if nargin >= 3 && ~isempty(log_dir_override)
                obj.log_dir = log_dir_override;
            else
                this_dir = fileparts(mfilename('fullpath'));
                obj.log_dir = fullfile(this_dir, 'logs');
            end
            if ~exist(obj.log_dir, 'dir')
                mkdir(obj.log_dir);
            end
            obj.log_seq = 0;
            stamp = datestr(now, 'yyyymmdd_HHMMSS');
            obj.log_path = fullfile(obj.log_dir, sprintf('robot_%s_%s.jsonl', ...
                regexprep(obj.robot_id, '[^\w\-]', '_'), stamp));
            obj.log_record('session_start', struct(...
                'base_url', obj.base_url, ...
                'robot_id', obj.robot_id, ...
                'note', 'robot-side self log (附件1 §4.6 / 附件2 §12)'));
            fprintf('[日志] 本局自记录日志: %s\n', obj.log_path);
        end

        %% /enter - 进入测试
        %  【2026-09-12 补等待窗口】接口只在倒计时结束后开放（附件1 §4.4：倒计时期间/非测试期间
        %  接口均未开放，连接失败属正常现象）。而 MATLAB 启动约 40 s、倒计时只有 5 s
        %  ⇒ 若程序恰好在倒计时那几秒内就绪，旧版只会重试 3 次（约 1.5 s）然后**退出**，
        %  用户会看到"程序莫名死掉"。按附件2 §12（网络中断后重试同一动作必须**复用原 request_id
        %  与原请求内容**）改为：**payload 只构造一次**，在 enter_wait_s 预算内反复重试直到被接受。
        %  ⚠️ 业务/协议拒绝（accepted=false、4xx）**不等待**，立刻抛 —— 那是配置错，等也没用。
        function resp = enter(obj)
            payload = struct(...
                'arena_id', 'default', ...
                'robot_id', obj.robot_id, ...
                'request_id', obj.new_request_id());   % ← 只生成一次，全程复用

            t_start = tic;
            while true
                try
                    resp = obj.send_request('/enter', payload);   % 内部已含传输层重试
                    obj.update_time(resp);
                    % 【P0-11】记录墙钟起点：表 1 第 4 列「程序运行时间」= /enter → 结束
                    obj.t_enter_wall = tic;
                    obj.elapsed_wall = 0;
                    if toc(t_start) > 1
                        fprintf('[SimulatorClient] /enter 等待 %.1f s 后成功\n', toc(t_start));
                    end
                    return;

                catch ME
                    if ~strcmp(ME.identifier, 'SimulatorClient:transport')
                        rethrow(ME);   % 业务/协议拒绝 ⇒ 配置问题，等下去没有意义
                    end
                    if toc(t_start) >= obj.enter_wait_s
                        error('SimulatorClient:enterTimeout', ...
                            ['/enter 等待 %.0f s 仍失败 —— 模拟器接口未开放或未启动。\n' ...
                             '  请确认：① 模拟器已启动并联网登录；② 已点「开始测试」且 5 秒倒计时已结束；\n' ...
                             '  ③ 端口未被占用（默认 2026）。\n  最后错误: %s'], ...
                            obj.enter_wait_s, ME.message);
                    end
                    fprintf('[SimulatorClient] 接口尚未开放，%.0f s 后重试 /enter（复用同一 request_id）...\n', ...
                        obj.enter_retry_interval_s);
                    pause(obj.enter_retry_interval_s);
                end
            end
        end

        %% 【P0-11】墙钟耗时（现实时间）
        function s = wall_clock_s(obj)
            if isempty(obj.t_enter_wall)
                s = 0;
            else
                s = toc(obj.t_enter_wall);
                obj.elapsed_wall = s;
            end
        end

        %% /measure - 检测
        function resp = measure(obj, x, y, channel)
            % 输入检查
            if ~isfinite(x) || ~isfinite(y) || abs(x) > 2e6 || abs(y) > 2e6
                error('坐标无效: (%.2f, %.2f)', x, y);
            end
            if channel < 1 || channel > 20 || mod(channel, 1) ~= 0
                error('频道无效: %d', channel);
            end

            payload = struct(...
                'arena_id', 'default', ...
                'robot_id', obj.robot_id, ...
                'request_id', obj.new_request_id(), ...
                'position', struct('x', x, 'y', y), ...
                'channel', channel);

            resp = obj.send_request('/measure', payload);
            obj.update_time(resp);
        end

        %% /clear - 清除
        function resp = clear(obj, x, y, channel)
            % 输入检查
            if ~isfinite(x) || ~isfinite(y) || abs(x) > 2e6 || abs(y) > 2e6
                error('坐标无效: (%.2f, %.2f)', x, y);
            end
            if channel < 1 || channel > 20 || mod(channel, 1) ~= 0
                error('频道无效: %d', channel);
            end

            payload = struct(...
                'arena_id', 'default', ...
                'robot_id', obj.robot_id, ...
                'request_id', obj.new_request_id(), ...
                'position', struct('x', x, 'y', y), ...
                'channel', channel);

            resp = obj.send_request('/clear', payload);
            obj.update_time(resp);
        end

        %% /exit - 退出测试
        function resp = exit(obj)
            payload = struct(...
                'arena_id', 'default', ...
                'robot_id', obj.robot_id, ...
                'request_id', obj.new_request_id());

            resp = obj.send_request('/exit', payload);
        end

        %% 生成新的请求ID
        function req_id = new_request_id(obj)
            obj.request_counter = obj.request_counter + 1;
            req_id = sprintf('req_%d_%s', obj.request_counter, ...
                char(java.util.UUID.randomUUID().toString()));
        end

        %% 发送HTTP请求（含重试）+ 【新增】双检查 + 逐次落盘日志
        %
        % 重试口径（附件2 §5.3 / §12）：
        %   · 传输层失败（连不上 / 超时 / 接口未开放）⇒ **复用原 payload 与原 request_id 重试**
        %     —— 这正是赛题要求的"网络中断后重试同一动作"。
        %   · 已收到 HTTP 响应（无论 200 还是 4xx/5xx）⇒ **一律不重试**。
        %     业务拒绝（accepted=false）与协议错误重试同一个 ID+内容没有意义（§5.3），
        %     旧版在此重试 3 次后 rethrow ⇒ 程序崩，已修。
        function resp = send_request(obj, endpoint, payload)
            url = [obj.base_url, endpoint];
            last_msg = '';

            for attempt = 1:obj.max_retries
                http_status = [];
                resp = [];
                transport_err = '';
                err_id = '';
                try
                    options = weboptions(...
                        'RequestMethod', 'post', ...
                        'MediaType', 'application/json', ...
                        'Timeout', obj.timeout);
                    resp = webwrite(url, payload, options);
                    http_status = 200;   % webwrite 不抛即 2xx；赛题只定义 200 为成功

                catch ME
                    err_id = obj.ident_of(ME);
                    code = obj.status_of(ME);
                    if ~isempty(code)
                        % ---- 已收到 HTTP 响应（400/404/405/409/413/415/429/500）----
                        http_status = code;
                        resp = obj.body_of(ME);
                        transport_err = '';
                    else
                        % ---- 传输层失败：可复用原 ID 重试 ----
                        transport_err = ME.message;
                    end
                    last_msg = ME.message;
                end

                accepted = isstruct(resp) && isfield(resp, 'accepted') && isequal(resp.accepted, true);
                obj.log_record('request', struct(...
                    'endpoint', endpoint, ...
                    'attempt', attempt, ...
                    'request_id', obj.get_field(payload, 'request_id'), ...
                    'request_payload', payload, ...
                    'response_payload', resp, ...
                    'http_status', http_status, ...
                    'response_received', obj.is_http_status(http_status), ...
                    'accepted', accepted, ...
                    'virtual_time_s', obj.get_field(resp, 'virtual_time_s'), ...
                    'transport_error', transport_err, ...
                    'error_identifier', err_id));

                if accepted
                    return;                       % 成功
                end

                if ~isempty(transport_err)
                    % 传输层失败 ⇒ 允许重试（同 payload 同 request_id）
                    warning('[SimulatorClient] 传输失败 (第 %d/%d 次): %s', ...
                        attempt, obj.max_retries, transport_err);
                    if attempt < obj.max_retries
                        pause(0.5);
                        continue;
                    end
                    error('SimulatorClient:transport', ...
                        '传输层失败 %d 次，已放弃: [%s] %s', ...
                        obj.max_retries, err_id, transport_err);
                end

                % 收到响应但未被接受 ⇒ **不重试**，立刻报清楚（配置/协议错，重试无益）
                % 注：经 webwrite 拿不到 4xx 的 JSON 体（它抛的是普通 MException），
                %     故此处报告**状态码 + 标识符 + 服务端消息**；body 若拿到则一并给出。
                error('SimulatorClient:rejected', ...
                    '请求未被接受 (HTTP %s, accepted=%s)\n  标识符: %s\n  消息: %s\n  响应体: %s', ...
                    obj.fmt_status(http_status), ...
                    obj.fmt_status(obj.get_field(resp, 'accepted')), ...
                    err_id, last_msg, jsonencode(obj.safe(resp)));
            end

            error('SimulatorClient:exhausted', '重试 %d 次后仍未成功: %s', ...
                obj.max_retries, last_msg);
        end

        %% 【新增】把一次记录追加到 JSONL（每条 open/append/close —— 崩溃也不丢已记录内容）
        function log_record(obj, kind, extra)
            obj.log_seq = obj.log_seq + 1;
            % 实时刷新墙钟（旧版只在收尾调用 wall_clock_s，导致中途记录 elapsed_wall_s 恒为 0）
            if ~isempty(obj.t_enter_wall)
                obj.elapsed_wall = toc(obj.t_enter_wall);
            end
            rec = struct();
            rec.seq = obj.log_seq;
            rec.kind = kind;
            rec.wall_clock_ms = posixtime(datetime('now', 'TimeZone', 'local')) * 1000;
            rec.time_local = datestr(now, 'yyyy-mm-dd HH:MM:SS.FFF');
            if isfield(extra, 'virtual_time_s')
                rec.virtual_time_s = extra.virtual_time_s;
            end
            rec.robot_id = obj.robot_id;
            rec.elapsed_wall_s = obj.elapsed_wall;
            f = fieldnames(extra);
            for i = 1:numel(f)
                rec.(f{i}) = extra.(f{i});
            end
            try
                fid = fopen(obj.log_path, 'a');
                if fid > 0
                    fprintf(fid, '%s\n', jsonencode(rec));
                    fclose(fid);
                end
            catch ME
                warning('[SimulatorClient] 日志写入失败: %s', ME.message);
            end
        end

        %% 【新增】收尾：写一条 end 记录（表 1 第 4 列「程序运行时间」= /enter → 结束）
        function close_log(obj)
            obj.log_record('session_end', struct(...
                'program_run_time_s', obj.wall_clock_s(), ...
                'virtual_time_s', obj.virtual_time, ...
                'log_path', obj.log_path));
        end

        function p = get_log_path(obj)
            p = obj.log_path;
        end

        %% 【新增】结构化日志的大小（MB）——附件1 §4.6：模拟器加密日志上限 2MB；
        %% 本函数量的是**机器狗自记录**的体量，供演练时核对"有无异常高频循环"
        function mb = log_size_mb(obj)
            d = dir(obj.log_path);
            if isempty(d), mb = 0; else, mb = d.bytes / 1024 / 1024; end
        end

        %% 更新时间跟踪
        %  【2026-09-12 修正】旧版写成 `resp.virtual_time_s > 0` 才更新 ——
        %  但 accepted=true 时 virtual_time_s **可以为 0**（/enter 就是 0），
        %  且 accepted=false 时也会给 0（附件2 §4.1：那个 0 不是当前虚拟时刻）。
        %  现在 send_request 已保证：走到这里的响应必为 accepted=true ⇒ 直接采用。
        function update_time(obj, resp)
            if isfield(resp, 'virtual_time_s') && ~isempty(resp.virtual_time_s)
                obj.virtual_time = resp.virtual_time_s;
            end

            if isfield(resp, 'remaining_real_duration_s')
                obj.remaining_time = resp.remaining_real_duration_s;
            end
        end

        %% 检查时间安全性
        function safe = is_time_safe(obj, time_reserve)
            safe = obj.remaining_time > time_reserve;
        end

        %% ------------------------------------------------------------------
        %% 【新增】小工具
        %% ------------------------------------------------------------------

        function v = get_field(obj, s, name)
            if isstruct(s) && isfield(s, name)
                v = s.(name);
            else
                v = [];
            end
        end

        function s = fmt_status(obj, v)
            if isempty(v)
                s = 'n/a';
            elseif islogical(v)
                if v, s = 'true'; else, s = 'false'; end
            elseif isnumeric(v)
                s = sprintf('%g', v);
            else
                s = char(string(v));
            end
        end

        function out = safe(obj, v)
            if isempty(v)
                out = struct('empty', true);
            else
                out = v;
            end
        end

        %% 是否"确实收到了 HTTP 响应"（2xx/4xx）
        %  必须防御空值：传输层失败时 http_status 为 []，
        %  而 `[] >= 200 && ...` 会抛 MATLAB:nonLogicalConditional（已踩过一次）
        function tf = is_http_status(obj, c)
            tf = ~isempty(c) && isnumeric(c) && isscalar(c) && isfinite(c) && ...
                 c >= 200 && c < 500;
        end

        %% 从异常里取出 HTTP 状态码；取不到返回 []（= 判为传输层失败，可重试）
        %
        % 【2026-09-12 实测修正】`webwrite` 在 HTTP 4xx/5xx 时抛的是**普通 MException**
        % （**不是** `matlab.net.http.HTTPException`，**没有** Response 属性）：
        %     class      = MException
        %     identifier = MATLAB:webservices:HTTP400StatusCodeError     ← 状态码编码在标识符里
        % 连不上时是：
        %     identifier = MATLAB:webservices:ConnectionRefused           ← 传输层，可重试
        % ⇒ 因此**按标识符分类**（比"有没有 Response"可靠）。探针见 commit 说明。
        function code = status_of(obj, ME)
            code = [];
            e = ME;
            while ~isempty(e)
                try
                    if isprop(e, 'Response') && ~isempty(e.Response)
                        code = double(e.Response.StatusCode);
                        return;
                    end
                catch
                end
                tok = regexp(e.identifier, ...
                    '^MATLAB:webservices:HTTP(\d{3})StatusCodeError$', 'tokens', 'once');
                if ~isempty(tok)
                    code = str2double(tok{1});
                    return;
                end
                try
                    e = e.cause{1};
                catch
                    e = [];
                end
            end
        end

        %% 取异常标识符（用于日志诊断；沿 cause 链取第一个非空）
        function id = ident_of(obj, ME)
            id = '';
            e = ME;
            while ~isempty(e)
                if ~isempty(e.identifier)
                    id = e.identifier;
                    return;
                end
                try
                    e = e.cause{1};
                catch
                    e = [];
                end
            end
        end

        %% 从 HTTP 异常里尽力取到响应体（沿 cause 链找带 Response 的那一层）
        function body = body_of(obj, ME)
            body = struct('unparsable_body', true);
            e = ME;
            while ~isempty(e)
                try
                    if isprop(e, 'Response') && ~isempty(e.Response)
                        body = obj.try_parse_body(e.Response);
                        return;
                    end
                catch
                    % 继续找
                end
                try
                    e = e.cause{1};
                catch
                    e = [];
                end
            end
        end

        %% 从 HTTP 异常里尽力取到响应体（可能是 struct / 字符串 / 取不到）
        function body = try_parse_body(obj, response)
            body = struct('unparsable_body', true);
            if isempty(response)
                return;
            end
            try
                data = response.Body.Data;
                if isstruct(data)
                    body = data;
                elseif ischar(data) || isstring(data)
                    body = jsondecode(char(data));
                end
            catch
                % 保持 unparsable 标记
            end
        end
    end
end
