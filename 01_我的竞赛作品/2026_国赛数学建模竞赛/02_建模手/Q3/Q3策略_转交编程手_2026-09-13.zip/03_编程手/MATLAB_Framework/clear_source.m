% ========================================================================
% 三路清除策略函数
% ========================================================================
% 文件: clear_source.m
% 功能: 根据R_MEC选择清除方式（直接/扫掠/homing）
% 日期: 2026-09-11
%
% 公式: Q3-F61 (三路选择)
% ========================================================================

function [success, cost, mode] = clear_source(source, sim_client, config, start_pos, start_theta)
    R_MEC = source.R_MEC;
    channel = source.channel;
    c_star = source.c_star;  % 最小包围圆圆心

    if R_MEC <= config.R_clear
        % 直接清除
        mode = 'direct';
        [success, cost] = direct_clear(c_star, channel, sim_client, config);

    elseif R_MEC <= config.R_star
        % 扫掠清除
        mode = 'sweep';
        [success, cost] = sweep_clear(source.L, R_MEC, c_star, channel, sim_client, config);

    else
        % Homing 逼近
        % 【2026-09-12】可选 start_pos/start_theta 透传：阶段 C 收尾时频道**已有示向度**，
        % 可直接从那个观测点 homing，无需先交会定位（详见 homing_clear 的注释）。
        mode = 'homing';
        if nargin >= 4 && ~isempty(start_pos)
            [success, cost] = homing_clear(source.L, channel, sim_client, config, ...
                                           start_pos, start_theta);
        else
            [success, cost] = homing_clear(source.L, channel, sim_client, config);
        end
    end
end

%% 直接清除（R_MEC ≤ 20）
function [success, cost] = direct_clear(c_star, channel, sim_client, config)
    fprintf('    [清除] 直接清除 频道 %d\n', channel);

    result = sim_client.clear(c_star(1), c_star(2), channel);
    success = strcmp(result.clear_result, 'success');

    if success
        cost = config.T_clear_success;
    else
        cost = config.T_clear_fail;
    end
end

%% 扫掠清除（20 < R_MEC ≤ 84.0369）
%  【2026-09-12 重写 —— 旧版按包围盒暴力铺点，实测平均浪费 ~10-19 个探点】
%  实测证据（`logs/robot_XX队号_20260912_221255.jsonl`）：ch=13 的清除序列是
%    (-1182.5,-81.4) → (-1202.5,-81.4) → (-1182.5,-61.4) → ... 20 m 网格螺旋外扩，
%    **试了 19 次 no_target_in_range 才命中** ⇒ 白走 ~1000 m + 57 s。
%  原因：源离三角化得到的 c* 有几十米，而旧版按"距 c* 升序"逐个试包围盒格点。
%  改法（**有保证**）：在 c* 先测一次拿示向度 ⇒ 沿方位走一个清除半径 R_clear 再清 ⇒ 重复。
%    保证：方位误差 ≤1°，在距离 R 处的横偏 ≈ 0.0175·R；R ≤ R_star = 84 m ⇒ 横偏 ≤1.5 m，
%    而每 20 m 采样一次 ⇒ 最近采样点到源 ≤10+1.5 m **必然 ≤20 m** ⇒ 一定命中。
%    步数上限 ⌈R_MEC/R_clear⌉+3 ⇒ R_MEC=84 时约 8 步，远少于旧版的 ~20 探点。
%  兜底：若某步测不到示向度（超出接收半径/定向盲区），退回到"以 c* 为中心的 8 邻域 20 m 格点"
%    逐个试清（数量少、开销可控），仍不做包围盒大范围铺点。
function [success, cost] = sweep_clear(L, R_MEC, c_star, channel, sim_client, config)
    fprintf('    [清除] 扫掠清除 频道 %d, R_MEC=%.2f m（定向短走）\n', channel, R_MEC);

    pos = c_star(:)';
    total_cost = 0;

    % 第 0 步：就地试一次（源可能就在 c* 的 20 m 内 —— 通常如此）
    r = sim_client.clear(pos(1), pos(2), channel);
    total_cost = total_cost + config.T_clear_fail;
    if strcmp(r.clear_result, 'success')
        success = true;
        cost = config.T_clear_success;
        return;
    end

    step = config.R_clear;
    n_max = ceil(R_MEC / step) + 3;
    for k = 1:n_max
        m = sim_client.measure(pos(1), pos(2), channel);
        total_cost = total_cost + config.T_measure;

        if strcmp(m.measure_result, 'near')
            [success, cost_clear] = direct_clear(pos, channel, sim_client, config);
            cost = total_cost + cost_clear;
            return;
        end

        [ok, th] = svd_of(m);
        if ~ok
            break;      % 测不到方位 ⇒ 走兜底
        end

        pos = pos + step * [cosd(th), sind(th)];
        r = sim_client.clear(pos(1), pos(2), channel);
        total_cost = total_cost + config.T_clear_fail;
        if strcmp(r.clear_result, 'success')
            success = true;
            cost = total_cost + 2.0;      % 补上清除动作那 2 s
            return;
        end
    end

    % ---- 兜底：以 c* 为中心的 8 邻域（20 m 格点）逐个试，不做包围盒大范围铺点 ----
    offs = [step 0; -step 0; 0 step; 0 -step;
            step step; step -step; -step step; -step -step];
    for i = 1:size(offs, 1)
        q = c_star(:)' + offs(i, :);
        r = sim_client.clear(q(1), q(2), channel);
        total_cost = total_cost + config.T_clear_fail;
        if strcmp(r.clear_result, 'success')
            success = true;
            cost = total_cost + 2.0;
            return;
        end
    end

    success = false;
    cost = total_cost;
end

%% Homing 逼近（R_MEC > 84.0369）
%  【2026-09-12 重写 —— 原实现**不收敛**，实测把一整局拖垮】
%  实测证据（d=1500 试跑，`logs/robot_XX队号_20260912_210451.jsonl`）：
%    ch=16 的 homing 轨迹是**4 个点无限循环**（每轮回到起点，转了 5 圈）；
%    ch=7 同样 4 点循环、步长 ~500 m。10 次迭代全废，每频道烧 ~1050 s 且**没清掉**
%    ⇒ 该局移动占 93.5%、虚拟时间 26242 s、12 源只清 7 个。
%  三个原因（都改掉）：
%    ① 步长 `h = D/2`（L 直径的一半）**过大**：d=1500 时 D 可达 1000~1500 m ⇒ 每步都过冲；
%    ② 过冲后"**回退半步**"（`pos = pos - 0.5*h*…`）⇒ 下一轮再冲回去 ⇒ **A→B→A 永久乒乓**；
%    ③ `h` **恒定不变**、无任何衰减 ⇒ 永无收敛。
%  新方案：**只前进、不后退**；步长上限 `R_homing_step_max`；
%    方位翻转（= 过冲）时把步长**减半**（几何衰减 ⇒ 必然收敛）；
%    总移动上限 `homing_max_move` 与迭代上限 `homing_max_iter` 保时间预算；
%    步长小于半个清除半径时就地试清一次。
function [success, cost] = homing_clear(L, channel, sim_client, config, start_pos, start_theta)
    % 防御性默认值：任何只带旧字段的 config 也能跑（避免 MATLAB:nonExistentField 直接中止）
    if ~isfield(config, 'R_homing_step_max'), config.R_homing_step_max = 300;  end
    if ~isfield(config, 'homing_max_iter'),   config.homing_max_iter   = 12;   end
    if ~isfield(config, 'homing_max_move'),   config.homing_max_move   = 2500; end

    fprintf('    [清除] Homing 逼近 频道 %d\n', channel);

    % 【2026-09-12 新增】两种启动方式：
    %   (a) 由 L 启动（常规：2 个观测交会得到 L）—— 起点取 L 的形心，先检测一次拿方位；
    %   (b) **单观测/单方位启动**（start_pos + start_theta 给出）—— 用于阶段 C 的收尾：
    %       某些频道检出过 direction 却**交会定位失败**（`triangulate_source` 在退化配置返回空）
    %       或只有 1 个观测 ⇒ 旧版只能**盲目重扫全部 13 个格点**（实测 223604 那局白花
    %       9 次检测 + 1427 m = **285 s**，且不保证清掉）。有方位就能直接 homing（附件2 §7.2）。
    if nargin >= 5 && ~isempty(start_pos)
        pos = start_pos(:)';
        theta = start_theta;
        total_cost = 0;
        D = [];
    else
        % 初始位置（L的中心）
        pos = mean(L, 1);

        % 初始检测
        result = sim_client.measure(pos(1), pos(2), channel);
        total_cost = config.T_measure;

        if strcmp(result.measure_result, 'near')
            [success, cost] = direct_clear(pos, channel, sim_client, config);
            return;
        end

        % 该字段**只在 measure_result="direction" 时存在**（附件2 §7.2/§12），
        % no_signal 时读它会报"无法识别的字段名"并中止程序（已踩过一次）。
        [ok, theta] = svd_of(result);
        if ~ok
            fprintf('      [Homing] 起点 (%.1f, %.1f) 无示向度（%s），放弃本频道本轮\n', ...
                pos(1), pos(2), result.measure_result);
            success = false;
            cost = total_cost;
            return;
        end

        D = Q1_geometry.polygon_diameter(L);
    end

    % 初始步长：取"定位不确定度半径"与上限的较小者（旧版无上限 ⇒ 必然过冲）
    if isempty(D)
        h = config.R_homing_step_max;      % 单方位启动：无 L ⇒ 直接用步长上限
    else
        h = min(D / 2, config.R_homing_step_max);
    end
    h = max(h, config.R_clear);          % 至少一个清除半径

    total_move = 0;
    for k = 1:config.homing_max_iter
        pos = pos + h * [cosd(theta), sind(theta)];
        total_move = total_move + h;

        result = sim_client.measure(pos(1), pos(2), channel);
        total_cost = total_cost + config.T_measure;

        if strcmp(result.measure_result, 'near')
            [success, cost_clear] = direct_clear(pos, channel, sim_client, config);
            cost = total_cost + cost_clear;
            fprintf('      [Homing] 第 %d 步抵达（累计移动 %.0f m）\n', k, total_move);
            return;
        end

        [ok, theta_new] = svd_of(result);
        if ~ok
            fprintf('      [Homing] 第 %d 步丢失信号（%s），停止逼近\n', k, result.measure_result);
            break;
        end

        if abs(angdiff(theta_new, theta)) > 90
            % 方位翻转 ⇒ 这一步**过冲了** ⇒ 步长减半（下一轮朝回指的方位走更小一步）
            h = h / 2;
        end
        theta = theta_new;

        if total_move >= config.homing_max_move
            fprintf('      [Homing] 累计移动达上限 %.0f m，停止逼近\n', config.homing_max_move);
            break;
        end

        if h < config.R_clear / 2
            % 步长已小于半个清除半径 ⇒ 就地试清一次（此时距源通常已 ≤20 m）
            [success, cost_clear] = direct_clear(pos, channel, sim_client, config);
            cost = total_cost + cost_clear;
            return;
        end
    end

    fprintf('      [Homing] 未收敛（累计移动 %.0f m），本频道本轮未清除\n', total_move);
    success = false;
    cost = total_cost;
end

%% 【新增】安全取示向度：只有 measure_result=="direction" 才读 svd_deg
%  附件2 §7.2：svd_deg 仅当 measure_result="direction" 时返回；
%  no_signal / near 时读它会报"无法识别的字段名"。
function [ok, deg] = svd_of(result)
    ok = isfield(result, 'measure_result') && strcmp(result.measure_result, 'direction') ...
         && isfield(result, 'svd_deg') && ~isempty(result.svd_deg);
    if ok
        deg = result.svd_deg;
    else
        deg = NaN;
    end
end

%% 辅助函数：角度差（处理环绕）
function diff = angdiff(phi, theta)
    diff = mod(phi - theta + 180, 360) - 180;
end
