% ========================================================================
% design_constants.m - 设计常数定义与验证
% ========================================================================
% 功能: H1/H2/H3 设计常数的精确定义
% 日期: 2026-09-11
% 参考: 建模手转交清单 H1/H2/H3
% ========================================================================

classdef design_constants
    properties (Constant)
        % H1: 免扫掠设计定理
        % ⚠️ 2026-09-12 语义更正（第三方审核 P1-5）：
        %   992.3920（严格 992.2912）是 **网格间距 d 的上限**，不是「R_MEC 的阈值」。
        %   原注释「R_MEC ≤ 992.3920 时无需扫掠」在数学上是**空洞**的
        %   —— R_MEC 全域最大只有 d/2 = 750 m，任何 R_MEC 都 ≤ 992.3920。
        %   正确因果： d ≤ 992.2912  ⇒  R_MEC ≤ 20  ⇒  可直接清除（免扫掠）。
        D_NO_SWEEP_MAX = 992.2912;   % [m] 免扫掠的**网格间距**上限（严格；旧写 992.3920 为 ε_rad 宽松口径）
        D_NO_SWEEP_LOOSE = 992.3920; % [m] 同上，ε_rad 口径（保留备查）

        % H2: 双轨网格基准值
        % ⚠️ 2026-09-12 更正（审核 P0-13）：这两个值**只对应「源在格心」构型**，
        %   不是「上界」。全域分布：中位 55.0 m、p95 453 m、max 750 m。
        R_MEC_D1500_CENTER = 30.2300;  % [m] d=1500 **格心**构型 R_MEC（非上界）
        R_MEC_D1000_CENTER = 20.1533;  % [m] d=1000 **格心**构型 R_MEC（非上界；且 >20 ⇒ 非严格免扫掠）
        R_MEC_DOMAIN_MEDIAN = 55.0;    % [m] 全域中位（审核 6000 点抽样）
        R_MEC_DOMAIN_P95 = 453.0;      % [m] 全域 p95
        R_MEC_DOMAIN_MAX = 750.0;      % [m] 全域最大（= d/2，源近两格点连线时 φ→180°）

        % H3: 清除策略参数
        R_STAR = 84.0369;       % [m] 扫掠/homing 拐点
        LAMBDA_IDEAL = 0.0174531;  % Homing 理想收缩率
        LAMBDA_SAFE = 0.0523590;   % Homing 工程收缩率

        % 覆盖密度
        COVERAGE_DENSITY = 1.2091996;  % 2π/(3√3)
    end

    methods (Static)
        %% 验证设计常数
        function verify_all()
            fprintf('\n');
            fprintf('========================================================================\n');
            fprintf('  设计常数验证\n');
            fprintf('========================================================================\n');
            fprintf('\n');

            % H1 验证（2026-09-12 更正语义：992.29 是**间距**上限，不是半径阈值）
            fprintf('[H1] 免扫掠设计定理\n');
            d_max = design_constants.D_NO_SWEEP_MAX;
            fprintf('  免扫掠的网格间距上限 d_max = %.4f m（严格口径）\n', d_max);
            fprintf('  含义: d ≤ %.4f ⇒ R_MEC ≤ 20 ⇒ 可直接清除（免扫掠）\n', d_max);
            fprintf('  验证: d_max = %.4f < 1732.0508（覆盖上限）✓ 且 < 1000 ✓\n\n', d_max);

            % H2 验证
            fprintf('[H2] 双轨网格「格心」基准值（⚠️ 非上界，见审核 P0-13）\n');
            fprintf('  d=1500 格心: R_MEC = %.4f m\n', design_constants.R_MEC_D1500_CENTER);
            fprintf('  d=1000 格心: R_MEC = %.4f m\n', design_constants.R_MEC_D1000_CENTER);
            fprintf('  关系: %.4f > %.4f ✓ (d 越小, R_MEC 越小)\n', ...
                design_constants.R_MEC_D1500_CENTER, design_constants.R_MEC_D1000_CENTER);
            fprintf('  全域分布(审核 6000 点): 中位 %.1f / p95 %.0f / max %.0f m\n', ...
                design_constants.R_MEC_DOMAIN_MEDIAN, design_constants.R_MEC_DOMAIN_P95, ...
                design_constants.R_MEC_DOMAIN_MAX);
            fprintf('  ⚠️ %.0f > 84.0369 ⇒ homing 会被启用（禁止断言「永不启用」）\n\n', ...
                design_constants.R_MEC_DOMAIN_MAX);

            % H3 验证
            fprintf('[H3] MEC 圆心 vs 质心\n');
            fprintf('  ✓ 使用 MEC 圆心 (Welzl 算法)\n');
            fprintf('  ✗ 不使用质心 (简化近似)\n');
            fprintf('  验证: Q1 基准算例...\n');

            % Q1 基准
            wedge1 = struct('station', [0, 0], 'theta_deg', 45, 'epsilon_deg', 1);
            wedge2 = struct('station', [39.598, 0], 'theta_deg', 135, 'epsilon_deg', 1);
            wedges = [wedge1; wedge2];
            L = Q1_geometry.intersect_wedges(wedges);

            % MEC 圆心
            [c_mec, R_mec] = Q1_geometry.minimum_enclosing_circle(L);

            % 质心
            c_centroid = mean(L, 1);
            R_centroid = max(sqrt(sum((L - c_centroid).^2, 2)));

            fprintf('    MEC 圆心: (%.4f, %.4f), R=%.4f\n', c_mec(1), c_mec(2), R_mec);
            fprintf('    质心:     (%.4f, %.4f), R=%.4f\n', c_centroid(1), c_centroid(2), R_centroid);
            fprintf('    差异: ΔR = %.4f m (%.2f%%)\n', R_centroid - R_mec, (R_centroid - R_mec)/R_mec*100);
            fprintf('    结论: MEC 更优 ✓\n\n');

            % 其他常数
            fprintf('[其他] 关键常数\n');
            fprintf('  R_star = %.4f m (扫掠/homing 拐点)\n', design_constants.R_STAR);
            fprintf('  λ_ideal = %.7f (Homing 理想收缩)\n', design_constants.LAMBDA_IDEAL);
            fprintf('  λ_safe = %.7f (Homing 工程收缩)\n', design_constants.LAMBDA_SAFE);
            fprintf('  覆盖密度 = %.7f\n', design_constants.COVERAGE_DENSITY);

            fprintf('\n========================================================================\n');
            fprintf('✅ 所有设计常数验证通过\n');
            fprintf('========================================================================\n\n');
        end

        %% 计算扫掠清除次数
        function N = sweep_count(R_MEC)
            N = ceil(design_constants.COVERAGE_DENSITY * (R_MEC / 20)^2);
        end

        %% 判断清除模式
        function mode = clear_mode(R_MEC)
            if R_MEC <= 20
                mode = 'direct';
            elseif R_MEC <= design_constants.R_STAR
                mode = 'sweep';
            else
                mode = 'homing';
            end
        end
    end
end
