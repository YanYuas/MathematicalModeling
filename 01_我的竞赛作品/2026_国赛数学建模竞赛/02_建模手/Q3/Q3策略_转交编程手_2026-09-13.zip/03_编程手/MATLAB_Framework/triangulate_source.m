% ========================================================================
% triangulate_source.m - 交会定位函数 (完整版)
% ========================================================================
% 功能: 从观测数据交会定位干扰源
% 输入: observations - 观测记录，config - 配置参数
% 输出: source_info - 源信息结构体
% ========================================================================

function source_info = triangulate_source(observations, config)
    % P0-1 修正：字段访问全部放进 try，缺字段时返回 []，不抛异常穿透主程序
    source_info = [];
    if length(observations) < 2
        return;
    end

    try
        % 取前两个观测构造角域
        obs1 = observations(1);
        obs2 = observations(2);
        if ~isfield(obs1, 'position') || ~isfield(obs2, 'position')
            warning('观测缺少 position 字段，跳过该频道本轮定位');
            return;
        end

        % 构造角域
        wedge1 = struct(...
            'station', [obs1.position(1), obs1.position(2)], ...
            'theta_deg', obs1.svd_deg, ...
            'epsilon_deg', config.epsilon_deg);

        wedge2 = struct(...
            'station', [obs2.position(1), obs2.position(2)], ...
            'theta_deg', obs2.svd_deg, ...
            'epsilon_deg', config.epsilon_deg);

        wedges = [wedge1; wedge2];
        % 1. 求角域交集
        L = Q1_geometry.intersect_wedges(wedges);

        if isempty(L)
            source_info = [];
            return;
        end

        % 2. 圆域截断
        L = clip_to_domain(L, config.R_domain);

        if isempty(L)
            source_info = [];
            return;
        end

        % 3. 计算最小包围圆
        [c_star, R_MEC] = Q1_geometry.minimum_enclosing_circle(L);

        % 4. 计算直径
        [D, ~, ~] = Q1_geometry.polygon_diameter(L);

        % 构造源信息
        source_info = struct();
        source_info.channel = obs1.channel;
        source_info.L = L;
        source_info.c_star = c_star;
        source_info.R_MEC = R_MEC;
        source_info.D = D;
        source_info.discovered_at = [obs1.position_id, obs2.position_id];

    catch ME
        warning('交会定位失败: %s', ME.message);
        source_info = [];
    end
end

%% 辅助函数: 圆域截断
function L_clipped = clip_to_domain(L, R)
    % 保留圆域内的点
    distances = sqrt(sum(L.^2, 2));
    L_clipped = L(distances <= R + 1e-9, :);
end
