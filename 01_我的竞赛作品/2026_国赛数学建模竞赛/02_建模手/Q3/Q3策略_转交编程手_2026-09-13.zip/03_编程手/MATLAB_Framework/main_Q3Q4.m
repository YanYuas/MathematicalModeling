% ========================================================================
% CUMCM2026 B题 Q3/Q4 MATLAB框架 - 主控脚本
% ========================================================================
% 文件: main_Q3Q4.m
% 功能: Q3/Q4 机器狗自动搜索定位与清除策略主程序
% 日期: 2026-09-11
% 修改: 2026-09-12 —— ① 【队号入口】robot_id 改为**必需参数**（附件2 §5.1：必须逐字节等于
%          当前登录参赛队号；格式规范要求支撑材料中隐去队号 ⇒ **源码不留真号**）。
%          ② 【表 1 四列】结束时打印 测试案例编码 / 清除干扰源个数 / 平均定位清除时间 /
%          程序运行时间（第 4 列 = /enter → 结束的墙钟时长，附件1 §4.6）。
%          ③ 收尾阶段补上"发现后真清除"（旧版只 break，没有清除 ⇒ 直接拉低清除比例）。
%
% 使用方法（推荐用同目录 一键_跑Q3.bat，它会提示输入队号）:
%   matlab -batch "main_Q3Q4('Q3','<参赛队号>')"
%   matlab -batch "main_Q3Q4('Q4','<参赛队号>','<测试案例编码>')"
%
% 依赖: MATLAB R2020a+ (webwrite) —— 本机 R2026a 已实跑验证
% ========================================================================

function results = main_Q3Q4(problem_type, robot_id, case_code, sim_url, grid_spacing)
    %% 0. 参数检查与初始化
    if nargin < 1 || isempty(problem_type)
        problem_type = 'Q3';  % 默认 Q3
    end
    if nargin < 3
        case_code = '';       % 测试案例编码：从模拟器界面抄（附件1 §4.6），可留空
    end
    if nargin < 4 || isempty(sim_url)
        sim_url = '';         % 空 = 用配置里的默认地址（http://127.0.0.1:2026）
    end
    if nargin < 5
        grid_spacing = [];    % 【2026-09-12】空 = 用 load_config 里的默认档
    end

    fprintf('\n');
    fprintf('========================================================================\n');
    fprintf('  CUMCM2026 B题 %s - 机器狗自动搜索定位与清除\n', problem_type);
    fprintf('========================================================================\n');
    fprintf('\n');

    %% 1. 加载配置参数
    config = load_config(problem_type);

    % 可选覆写模拟器地址 —— 仅供**离线自测**（把 mock 挂在别的端口，不动真模拟器的 2026）
    if ~isempty(sim_url)
        config.simulator_url = sim_url;
        fprintf('[模拟器] 地址被覆写为 %s（离线自测用）\n', sim_url);
    end

    % 【2026-09-12 新增】可选覆写网格间距 —— 让"试 d=1000 / d=1500"**不用改源码**，
    %   避免仓库停在中间状态；也便于两种配置背靠背对比。
    %   用法：main_Q3Q4('Q3', 队号, 案例编码, [], 1500)
    if ~isempty(grid_spacing)
        fprintf('[网格] 间距 d 被覆写为 %.0f m（原 %s）\n', grid_spacing, ...
            num2str(config.grid_spacing));
        config.grid_spacing = grid_spacing;
    end

    % 【新增】队号入口：附件2 §5.1「robot_id 必须逐字节等于当前登录参赛队号」
    %   ⇒ 源码里不写死，运行时由参数传入（同时满足格式规范"支撑材料中隐去队号"）
    if nargin < 2 || isempty(robot_id)
        error(['缺少参赛队号。请用:  matlab -batch "main_Q3Q4(''%s'',''<参赛队号>'')"' ...
               newline '或直接双击同目录的  一键_跑Q3.bat （会提示输入队号）。'], problem_type);
    end
    config.robot_id = robot_id;
    fprintf('[队号] robot_id = %s（运行期传入，源码不含真实队号）\n', config.robot_id);
    if ~isempty(case_code)
        fprintf('[案例] 测试案例编码 = %s\n', case_code);
    end

    %% 2. 连接模拟器
    fprintf('[模拟器] 连接中...\n');
    sim_client = SimulatorClient(config.simulator_url, config.robot_id);

    % 进入测试
    try
        enter_resp = sim_client.enter();
        fprintf('[模拟器] /enter 成功！本局可用现实时间: %.1f s\n', ...
            enter_resp.remaining_real_duration_s);
        if enter_resp.remaining_real_duration_s < 1200
            fprintf('[提示] 不足 1200 s —— 说明 /enter 晚于窗口开始 5 分钟，按剩余时间规划\n');
        end
    catch ME
        error('[错误] 模拟器连接/进入失败: %s', ME.message);
    end

    %% 3. 生成检测点网格
    fprintf('\n[阶段 1] 生成检测点网格...\n');
    is_Q4 = strcmp(problem_type, 'Q4');

    if is_Q4
        % ===== P0-3 接线：Q4 用「外扩环带」（宽度 = d，见 Q4_extensions 更正），不用圆内裁剪 =====
        detection_points = Q4_extensions.generate_extended_grid(...
            config.grid_spacing, config.R_domain, config.R_sensor);
        fprintf('[网格] Q4 外扩环带：%d 个检测点 (d=%.1f m)\n', ...
            size(detection_points, 1), config.grid_spacing);

        % 全域零漏点自检（surrounding；P0-3(ii)）
        [surr_ok, ~, ~] = Q4_extensions.check_surrounding_all(...
            detection_points, config.R_domain, config.R_sensor);
        if ~surr_ok
            warning('[Q4] 全域 surrounding 自检未通过 —— 策略的「100%% 清除」依据不成立');
        end
    else
        grid_params = struct(...
            'd', config.grid_spacing, ...
            'R_domain', config.R_domain, ...
            'extend_for_Q4', false);
        detection_points = generate_triangular_grid(grid_params);
        fprintf('[网格] 生成 %d 个检测点 (d=%.1f m)\n', size(detection_points, 1), config.grid_spacing);

        % 覆盖自检（Q3 用 1000-覆盖）
        coverage_ok = check_coverage(detection_points, config);
        if ~coverage_ok
            error('[错误] 覆盖自检失败！');
        end
        fprintf('[自检] 覆盖验证通过 ✓\n');
    end

    %% 4. 初始化状态管理器
    fprintf('\n[阶段 2] 初始化状态管理...\n');
    state = ChannelStateMachine(config.n_channels, size(detection_points, 1));

    %% 5. 阶段 A: 侦察 - 扫描所有检测点（**动态重规划 + 发现即清除**）
    fprintf('\n[阶段 A] 侦察阶段 - 扫描检测点（动态重规划）...\n');
    % 【2026-09-12 改】旧版先算一次固定顺序 `route_A`，之后一路照着走。
    %   问题：一旦中途拐去清除（"发现即清除"），回来还得飞回**序号位置** ⇒ 折返量很大。
    %   离线迷你模拟器实测（seed=2026, n=13）：总移动 **27878 m**，其中
    %   格点间应有的行程只有 ~12000 m ⇒ **约 16000 m 是折返**。
    %   现改为**每一步都从当前落点对"剩余格点"重规划**（复用 optimize_route，
    %   规模 ≤13 点，开销可忽略）⇒ "下一站"永远是离当前位置最近的未扫格点。
    n_pts = size(detection_points, 1);
    remaining = true(n_pts, 1);
    step_i = 0;

    discovered_sources = cell(0);  % 存储已定位的源信息
    cur_pos = [0, 0];              % 【2026-09-12】跟踪当前落点，供阶段 B 就近排序
    current_channel = 1;  % 当前测向机频道

    pending = cell(0);             % 【2026-09-12】已定位但**未**清除的源
    while any(remaining) || ~isempty(pending)
        % 防御：清掉空槽（否则 `~isempty(pending)` 可能永远为真 ⇒ 死循环）
        if ~isempty(pending)
            pending = pending(~cellfun(@isempty, pending));
        end
        % 【2026-09-12 任务表调度】把"剩余格点"与"待清源"放进**同一个任务表**，每步取**最近的任务**。
        %   为什么必须这样：离线迷你模拟器实测（seed=2026, n=13）——
        %     只做"发现即冲过去清"时，总移动 **27150 m**，而格点间行程本该只有 ~12000 m
        %     ⇒ **约 15000 m 是"去源再折返"**：等于把"扫描路线"和"源行程"**相加**。
        %   单条巡游（把两类任务交织）约 15000 m ⇒ 差额 ~12000 m ≈ **2400 s**。
        %   ⇒ 就近调度让"去清一个源"顺路发生，而不是专程往返。
        % 【2026-09-12 任务表调度 v2 —— 整体 NN+2-opt 取第一站】
        %   v1 是"逐点贪心最近"，实测仍留 **49~76 s/源** 的绕路
        %   （用三次/五次实跑的真实源位置算单巡游下界对比得出）。
        %   局部最优的典型：先清了近处的源，下一站却很远。
        %   v2 把「剩余格点 ∪ 待清源」当成**一个点集**，整体做 NN+2-opt（复用 optimize_route），
        %   取它的**第一站** —— 2-opt 能看到"这一步走这里、后面会绕远"的代价，从而避免。
        tasks = detection_points(remaining, :);
        kind_of = repmat({'grid'}, 1, size(tasks, 1));
        idx_of = find(remaining)';
        for k = 1:numel(pending)
            if isempty(pending{k}), continue; end
            if ~isfield(pending{k}, 'c_star') || isempty(pending{k}.c_star), continue; end
            tasks(end+1, :) = pending{k}.c_star(:)';
            kind_of{end+1} = 'clear';
            idx_of(end+1) = k;
        end
        if isempty(tasks), break; end
        ord = optimize_route(tasks, cur_pos);
        task_kind = kind_of{ord(1)};
        task_pick = idx_of(ord(1));

        if strcmp(task_kind, 'clear')
            % ---- 就近去清一个已知源 ----
            src = pending{task_pick};
            pending(task_pick) = [];        % 用**元素删除**（不是置空），保证 pending 会缩短
            if state.is_cleared(src.channel), continue; end
            fprintf('  [调度] 就近清除 频道 %d（距 %.0f m，任务表 %d 项）\n', ...
                src.channel, norm(src.c_star(:)' - cur_pos), numel(tasks));
            [ok_c, cost_c, mode_c] = clear_source(src, sim_client, config);
            if ok_c
                state.mark_cleared(src.channel);
                cur_pos = src.c_star(:)';
                fprintf('  [清除] 频道 %d 成功 (%s, %.1f s)\n', src.channel, mode_c, cost_c);
            else
                % 清不掉 ⇒ 交阶段 B 兜底重试（原逻辑保留）
                discovered_sources{end+1} = src;
                fprintf('  [清除] 频道 %d 未成功 (%s) ⇒ 转入阶段 B 兜底\n', src.channel, mode_c);
            end
            continue;
        end

        % ---- 就近去扫一个格点 ----
        pt_idx = task_pick;
        remaining(pt_idx) = false;
        step_i = step_i + 1;

        pos = detection_points(pt_idx, :);
        cur_pos = pos;             % 【2026-09-12】记录落点

        % 检查现实时间
        if sim_client.remaining_time < config.time_reserve
            fprintf('[警告] 现实时间不足，进入收尾阶段\n');
            break;
        end

        % 扫描所有频道
        for ch = 1:config.n_channels
            % 跳过已清除的频道
            if state.is_cleared(ch)
                continue;
            end

            % 检测
            result = sim_client.measure(pos(1), pos(2), ch);
            current_channel = ch;

            % 更新状态
            state.update(ch, pt_idx, result.measure_result, result, pos);

            % 处理结果
            if strcmp(result.measure_result, 'direction')
                % 发现信号，记录示向度
                fprintf('  [发现] 频道 %d 在点 %d 处测得示向度 %.2f°\n', ...
                    ch, pt_idx, result.svd_deg);

                % 尝试交会定位
                % 【2026-09-12 阶段 A/B 融合 —— "发现即清除"】
                %   理由（不是拍脑袋）：
                %     ① `triangulate_source` **只取 observations(1)/observations(2)**
                %        ⇒ 再多等几个观测**不会更准**，等待没有收益；
                %     ② 此刻我们正站在**能看见该源的格点之一**上 ⇒ 这是去清它的最便宜时机；
                %     ③ 旧版"扫完 13 点再回头清"实测多跑近一倍路程：2026-09-12 三次试跑
                %        阶段 A 扫描 ~2400 s，而阶段 B/C 的清除行程 **15000~15577 m ≈ 3000 s**
                %        （用单条巡游下界对比：可省 840~2773 s）。
                %   正确性：不破坏 100% 清除保证 —— 未清除频道仍会被扫完全部格点；
                %     已清除频道由循环顶部的 `state.is_cleared` 跳过。
                %   兜底：就地清不掉（homing/sweep 未成功）⇒ 照旧塞进 discovered_sources
                %     交给阶段 B 重试，原逻辑完全保留。
                if state.has_two_observations(ch)
                    source_info = triangulate_source(state.get_observations(ch), config);
                    if ~isempty(source_info)
                        % 【2026-09-12】不再"一发现就冲过去清"，而是**入待清队列**，
                        % 由任务表调度决定何时**顺路**去清（避免专程往返 —— 那是 15000 m 的来源）。
                        pending{end+1} = source_info;
                        fprintf('  [定位] 频道 %d 已定位 R_MEC=%.2f m ⇒ 入待清队列\n', ...
                            ch, source_info.R_MEC);
                    end
                end

            elseif strcmp(result.measure_result, 'near')
                % 距离很近，直接清除
                fprintf('  [Near] 频道 %d 在 5m 内\n', ch);
                clear_result = sim_client.clear(pos(1), pos(2), ch);
                if strcmp(clear_result.clear_result, 'success')
                    state.mark_cleared(ch);
                    fprintf('  [清除] 频道 %d 清除成功 ✓\n', ch);
                end

            elseif strcmp(result.measure_result, 'no_signal') && is_Q4
                % ===== P0-3 接线：Q4 的 no_signal 接入 surrounding / 扇区探针 =====
                action = Q4_extensions.handle_no_signal_Q4(...
                    pos, ch, detection_points, sim_client, config);
                if strcmp(action, 'skip') && Q4_extensions.is_surrounding(pos, detection_points, config.R_sensor)
                    % surrounding 成立 ⇒ 该点周围无漏测死角，此频道可跳过（不视为已确认空）
                    continue;
                end
            end
        end

        % 定期检查完备性
        if mod(step_i, 3) == 0
            [complete, stats] = state.check_completeness();
            fprintf('[进度] 已清除: %d, 已确认空: %d, 剩余: %d\n', ...
                stats.cleared, stats.confirmed_empty, stats.remaining);
        end
    end

    %% 5.5 【2026-09-12 新增 · 试跑风险探针】单观测频道预警
    %  为什么要有：`triangulate_source` **需要 2 个观测**才能交会定位。
    %  覆盖保证只保证「每个源至少被 1 个格点发现」；**"被 2 个格点发现"没有保证**。
    %  d=1000（13 格点）时格点密、本局 12 源平均各有 3.8 个观测点；
    %  **d=1500（7 格点）时明显变少** ⇒ 若某源只被 1 个格点发现，它就**永远不定位 ⇒ 永不清除**，
    %  直接打掉「清除比例」。⇒ 这一行把该风险在终端**当场暴露**，不用等日志分析。
    single_obs = [];
    for ch = 1:config.n_channels
        if state.is_cleared(ch) || state.is_confirmed_empty(ch)
            continue;
        end
        if numel(state.get_observations(ch)) == 1
            single_obs(end+1) = ch; %#ok<AGROW>
        end
    end
    if ~isempty(single_obs)
        fprintf('\n[风险] 以下频道**只被 1 个格点发现** —— 交会定位需 2 个观测 ⇒ **可能永不清除**：\n');
        fprintf('       %s\n', mat2str(single_obs));
        fprintf('       ⇒ 这是 d=1500 对照轨的已知风险；若这些频道最终未被清除，说明该档不适用。\n\n');
    else
        fprintf('\n[风险] 无单观测频道（每个未清除频道都有 >= 2 个观测）\n\n');
    end

    %% 6. 阶段 B: 清除 - 处理已定位的源
    fprintf('\n[阶段 B] 清除阶段...\n');
    % 【2026-09-12 优化】按「就近」重排清除顺序
    %   背景（实测）：原来按**发现顺序**清除，2026-09-12 真实演练中 12 个源的清除行程为
    %   **13160 m**；仅按最近邻+2-opt 重排即可降到 **8789 m** ⇒ **省 4371 m = 874 s**。
    %   只改**访问顺序**，不改任何判定/清除逻辑 ⇒ 不影响「100% 清除」的保证。
    discovered_sources = order_sources_nearest(discovered_sources, cur_pos);
    for i = 1:length(discovered_sources)
        source = discovered_sources{i};

        % 检查是否已清除
        if state.is_cleared(source.channel)
            continue;
        end

        % 三路清除策略
        [success, cost, mode] = clear_source(source, sim_client, config);
        if success
            state.mark_cleared(source.channel);
            fprintf('  [清除] 频道 %d 清除成功 (%s, %.1f s) ✓\n', ...
                source.channel, mode, cost);
        end
    end

    %% 7. 阶段 C: 收尾 —— 对"未清除但有示向度"的频道做**定向 homing**
    %  【2026-09-12 重写】旧版是**盲目重扫全部 13 个格点**（指望凑齐 2 个观测再交会定位）。
    %  实测代价：`logs/robot_XX队号_20260912_223604.jsonl` 那局花了 **9 次检测 + 1427 m
    %  行程 = 285 s**；223743 那局 90 s。而且**不保证能清掉** —— 走到这一步的频道恰恰是
    %  `triangulate_source` 在退化配置下**返回空**的那批（交会不出区域）。
    %  正解：这些频道**已经拿到过示向度**（附件2 §7.2：有 svd_deg 就能定向）⇒ 直接从该观测点
    %  homing 逼近：既省掉重扫行程，又真正把源清掉（保住表 1 的「清除干扰源个数」）。
    %  注：**无**观测的频道必然已在主循环里被 13 个格点全部判为 no_signal ⇒ `is_confirmed_empty`，
    %  不会走到这里。
    fprintf('\n[阶段 C] 收尾 —— 对未清除频道做定向 homing...\n');
    for ch = 1:config.n_channels
        if state.is_cleared(ch) || state.is_confirmed_empty(ch)
            continue;
        end
        obs = state.get_observations(ch);
        if isempty(obs)
            fprintf('  [收尾] 频道 %d 未清除且无观测（异常情形），跳过\n', ch);
            continue;
        end
        o = obs(1);
        fprintf('  [收尾] 频道 %d 有 %d 个观测 ⇒ 从 (%.1f, %.1f) 沿示向度 %.2f° homing\n', ...
            ch, numel(obs), o.position(1), o.position(2), o.svd_deg);
        % R_MEC = Inf ⇒ clear_source 必走 homing 分支；start_pos/start_theta 透传到 homing_clear
        src = struct('channel', ch, 'L', [], 'c_star', o.position(:)', ...
                     'R_MEC', Inf, 'D', 0);
        [okh, costh] = clear_source(src, sim_client, config, o.position(:)', o.svd_deg);
        if okh
            state.mark_cleared(ch);
            fprintf('  [清除] 频道 %d homing 成功 (%.1f s) ✓\n', ch, costh);
        else
            fprintf('  [收尾] 频道 %d homing 未成功（%.1f s）\n', ch, costh);
        end
    end
    [complete, stats] = state.check_completeness();

    %% 8. 退出测试
    fprintf('\n[结束] 调用 /exit...\n');
    exit_resp = sim_client.exit();

    %% 9. 统计结果
    [complete, stats] = state.check_completeness();
    results = struct();
    results.cleared_count = stats.cleared;
    results.total_count = stats.cleared + stats.remaining;
    if results.total_count > 0
        results.cleared_ratio = stats.cleared / results.total_count;
    else
        results.cleared_ratio = NaN;
    end
    results.virtual_time = sim_client.virtual_time;
    % 平均定位清除时间 = 定位清除总时间 / 被清除个数
    %   定位清除总时间 = 虚拟时钟累计（移动 + 频道切换 + 检测 + 光学精确定位 + 清除）
    %   见附件1 §2 / 附件2 §4 —— 这正是 virtual_time 的语义
    if stats.cleared > 0
        results.avg_time = results.virtual_time / stats.cleared;
    else
        results.avg_time = NaN;
    end
    % 表 1 第 4 列：程序运行时间 = /enter → 结束 的墙钟时长（附件1 §4.6）
    results.program_run_time = sim_client.wall_clock_s();
    results.case_code = case_code;
    results.log_path = sim_client.get_log_path();

    sim_client.close_log();   % 【新增】写 session_end 并落盘

    fprintf('\n========================================================================\n');
    fprintf('  测试完成\n');
    fprintf('========================================================================\n');
    % 【2026-09-12 修正】旧版写 `stats.cleared / total_count`，当 total_count=0（本局没发现任何源）
    % 时打印 "0 / 0 (NaN%)" —— 除零未屏蔽，看着像程序坏了。改为显式分情况，并**如实标注口径**：
    %   本程序**无法知道源总数**（附件2 §1.3：接口不返回总数，须自行判断）
    %   ⇒ total_count 只是「已清除 + 本地状态机判为未清」的**下界**，不是真总数。
    fprintf('已清除: %d', stats.cleared);
    if results.total_count > 0
        fprintf(' ／ 下界 %d（%.1f%%）  ← 分母来自本地状态机，**非**真源总数\n', ...
            results.total_count, results.cleared_ratio * 100);
    else
        fprintf('   （本局未发现任何源 ⇒ 比例无法计算）\n');
    end
    fprintf('虚拟时间(定位清除总时间): %.2f s\n', results.virtual_time);
    if isnan(results.avg_time)
        fprintf('平均定位清除时间: n/a（清除数为 0，已屏蔽除零）\n');
    else
        fprintf('平均定位清除时间: %.2f s\n', results.avg_time);
    end

    % ---- 【新增】表 1 复制块：附件3 要求按表 1 格式在论文里给出每局结果 ----
    % 表 1 四列 = 测试案例编码 / 清除干扰源个数 / 平均定位清除时间 / 程序运行时间
    % ⚠️ 表 1 **只要「清除干扰源个数」，不要比例** —— 因为正式测试不显示案例真值
    %   （附件1 §4.6），比例只在**演练测试**里用"界面给出的总数"计算。
    fprintf('\n---- 表 1 填写用（直接抄进论文） ----\n');
    fprintf('测试案例编码          : %s\n', ...
        ternary(isempty(case_code), '（从模拟器界面抄，附件1 §4.6）', case_code));
    fprintf('清除干扰源个数        : %d\n', results.cleared_count);
    fprintf('平均定位清除时间      : %s\n', ternary(isnan(results.avg_time), ...
        'n/a（清除数为 0）', sprintf('%.2f s', results.avg_time)));
    fprintf('程序运行时间          : %.2f s   (= /enter → 结束 墙钟)\n', ...
        results.program_run_time);
    fprintf('-------------------------------------\n');
    fprintf('机器狗自记录日志      : %s\n', results.log_path);
    fprintf('日志体积              : %.3f MB（附件1 §4.6：模拟器加密日志上限 2 MB；\n', ...
        sim_client.log_size_mb());
    fprintf('                        此值供演练时核对"有无异常高频循环"）\n');
    fprintf('⚠️ 另需从模拟器导出本局**加密行为日志**（不要改文件名）放入支撑材料\n');
    fprintf('========================================================================\n\n');
end

function out = ternary(cond, a, b)
    if cond, out = a; else, out = b; end
end

%% 【2026-09-12 新增】按「就近」重排待清除的源
%  排序基准用每个源的 `c_star`（最小包围圆圆心）—— 三路清除策略都是奔着 c_star 或其周围去的。
%  复用 `optimize_route`（NN + 2-opt），不另造算法。
function srcs = order_sources_nearest(srcs, from_pos)
    n = numel(srcs);
    if n < 2
        return;
    end
    pt = zeros(n, 2);
    for i = 1:n
        if isfield(srcs{i}, 'c_star') && ~isempty(srcs{i}.c_star)
            pt(i, :) = srcs{i}.c_star(:)';
        else
            pt(i, :) = from_pos(:)';
        end
    end
    order = optimize_route(pt, from_pos);
    if numel(order) == n
        srcs = srcs(order);
    end
end

%% ========================================================================
%  辅助函数
%% ========================================================================

function config = load_config(problem_type)
    %% 加载配置参数
    config = struct();

    % 模拟器参数
    config.simulator_url = 'http://127.0.0.1:2026';
    % robot_id 由 main_Q3Q4 的运行期入参注入（附件2 §5.1 必须等于当前登录参赛队号；
    % 格式规范要求支撑材料中隐去队号 ⇒ 此处**故意不设默认值**）
    config.robot_id = '';

    % 题设参数
    config.R_domain = 1800;          % 圆域半径 [m]
    config.R_sensor = 1000;          % 最坏接收半径 [m]
    config.R_clear = 20;             % 清除半径 [m]
    config.R_near = 5;               % near 阈值 [m]
    config.velocity = 5;             % 移动速度 [m/s]
    config.epsilon_deg = 1;          % 示向度误差 [°]
    config.n_channels = 20;          % 频道数

    % 时间参数
    config.T_measure = 5;            % 检测耗时 [s]
    config.T_switch = 1;             % 切换频道耗时 [s]
    config.T_clear_success = 5;      % 清除成功耗时 [s]
    config.T_clear_fail = 3;         % 清除失败耗时 [s]
    config.time_reserve = 60;        % 预留收尾时间 [s]

    % 网格间距 d：**回退到默认档 1000**（2026-09-12 d=1500 试跑实测不可用，见下）
    %   依据：建模手 v1.3.0 / 权威数字表 §二 —— 默认档 d=1000（免扫掠面积 81.6%）。
    %   ⚠️ **d=1500 试跑实测结果（2026-09-12，12 源案例）**：
    %     虚拟时间 **7343.9 → 26242.5 s**、移动占 **93.5%**、清除 **12 → 7 个**、
    %     均摊 **612 → 3748.9 s/源**（差 6 倍）⇒ **该档不可用**，已回退。
    %     直接原因：d=1500 定位不确定度大 ⇒ 大量落入 `homing` 分支，而 homing 当时是**不收敛**的
    %     （原地 4 点循环、每频道烧 ~1050 s）—— 审核 P0-14「d=1500 清除侧昂贵」的判断得到实测印证。
    %   ⚠️ 但 **homing 本身已修**（见 clear_source.m）：权威数字表记 **32.7% 的可解区需要 homing**
    %     ⇒ 即使 d=1000，正式测试也可能抽到需要 homing 的案例，修它是必须的。
    config.grid_spacing = 1000;

    % Homing 参数
    config.lambda_ideal = 2 * sind(0.5);  % 理想收缩率 = 0.0174531
    config.lambda_safe = sind(1) + 2 * deg2rad(1);  % 工程收缩率 = 0.0523590
    config.R_star = 84.0369;         % 扫掠/homing 拐点 [m]
    % 【2026-09-12 新增】homing 收敛参数
    %   背景：原 homing 用 h = D/2 作步长且**无收敛机制**，d=1500 实测原地 4 点循环、
    %   每频道烧 ~1050 s（且清不掉）。以下三个上限是收敛与时间预算的保证。
    config.R_homing_step_max = 300;  % 初始步长上限 [m]
    config.homing_max_iter   = 12;   % 最大迭代次数
    config.homing_max_move   = 2500; % 单次 homing 移动上限 [m]（超了就停，别吃掉整个窗口）

    % 覆盖参数
    config.coverage_density = 2*pi/(3*sqrt(3));  % 1.2091996
end
