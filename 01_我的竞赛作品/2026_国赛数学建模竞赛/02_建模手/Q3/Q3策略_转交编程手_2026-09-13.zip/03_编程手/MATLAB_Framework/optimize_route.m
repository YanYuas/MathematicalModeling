% ========================================================================
% 路径优化函数（TSP，开放路径）
% ========================================================================
% 文件: optimize_route.m
% 功能: 对检测点集求访问顺序（从起点出发，**不要求回到起点**）
% 日期: 2026-09-11
% 修改: 2026-09-12 —— **启用 2-opt**
%   背景（实测）：2026-09-12 真实演练里贪心最近邻给出 **15464 m**，其最后一跳是从
%   (1500,-866) 横穿到 (0,1732.1) 的 **3000 m**；同起点的 NN+2-opt 只要 **12000 m**
%   ⇒ **省 3464 m = 693 s 虚拟时间**（移动占该局虚拟时间 78%，是最大瓶颈）。
%   原代码里 `twoopt_optimize` 已写好但被注释掉（`% TODO: 2-opt 优化（可选）`），
%   且其目标函数 `route_distance` **漏算起点到首点的那一段** ⇒ 直接启用会优化错目标，已修。
% ========================================================================

function route = optimize_route(points, start_point)
    % points: Nx2 矩阵，每行是一个点
    % start_point: 2x1 或 1x2，起点坐标
    % route: 访问顺序的索引向量

    n = size(points, 1);
    if n == 0
        route = [];
        return;
    end

    sp = start_point(:)';

    % ---- 第一步：贪心最近邻（构造初始解）----
    visited = false(n, 1);
    route = zeros(n, 1);
    current_pos = sp;

    for i = 1:n
        distances = inf(n, 1);
        for j = 1:n
            if ~visited(j)
                distances(j) = norm(points(j, :) - current_pos);
            end
        end
        [~, nearest_idx] = min(distances);
        route(i) = nearest_idx;
        visited(nearest_idx) = true;
        current_pos = points(nearest_idx, :);
    end

    % ---- 第二步：2-opt 局部优化（2026-09-12 启用）----
    route = twoopt_optimize(points, route, sp);
end

%% 2-opt 局部优化（开放路径：目标含"起点 → 首点"那一段）
function route = twoopt_optimize(points, route, sp)
    best = path_length(points, route, sp);
    improved = true;
    while improved
        improved = false;
        m = numel(route);
        for i = 1:m-1
            for j = i+1:m
                cand = route;
                cand(i:j) = route(j:-1:i);      % 反转 i..j（i=1 也合法：等于换首点）
                lc = path_length(points, cand, sp);
                if lc < best - 1e-9
                    route = cand;
                    best = lc;
                    improved = true;
                end
            end
        end
    end
end

%% 开放路径长度（从 sp 出发，依次走 route，不回到 sp）
%  【2026-09-12 修正】旧版 `route_distance` 只算了 route 内部相邻段，
%  **漏掉"起点 → 首点"**这一跳 ⇒ 2-opt 会把目标优化错（尤其 i=1 的反转）。
function dist = path_length(points, route, sp)
    dist = 0;
    prev = sp;
    for i = 1:numel(route)
        cur = points(route(i), :);
        dist = dist + norm(cur - prev);
        prev = cur;
    end
end
