% ========================================================================
% 三角网格生成函数
% ========================================================================
% 文件: generate_triangular_grid.m
% 功能: 生成间距d的三角格，圆域裁剪后得检测点集P
% 日期: 2026-09-11
%
% 公式: Q3-F10
% ========================================================================

function P = generate_triangular_grid(params)
    % 输入参数
    d = params.d;                    % 网格间距 [m]
    R = params.R_domain;             % 圆域半径 [m]
    extend_for_Q4 = params.extend_for_Q4;  % Q4 是否外扩环带

    % 三角格基矢
    a1 = [d, 0];
    a2 = [d/2, sqrt(3)*d/2];

    % 生成范围（留 margin 避免边界漏）
    % 【2026-09-12 修正】Q4 外扩环带宽度由 `d/√3` 改为 **`d`**。
    %   原值 `d/√3` 是**最近邻**覆盖半径；而 Q4 的 surrounding 条件用**三最近邻**，
    %   第三最近邻可达 `d` ⇒ 环带若只外扩 `d/√3`，边界带会漏（实测失败率 42.05%，
    %   提到 `d` 后 0.00%）。见 `00_任务总控/权威数字表.md` §6.4 与
    %   `02_建模手/Q4/Q4建模数学化.md` L4′。
    %   注：`main_Q3Q4.m` 的 Q4 分支走 `Q4_extensions.generate_extended_grid`（已用 `d`），
    %   故本行**只影响**直接以 `extend_for_Q4=true` 调用本函数的路径——那是个**遗留陷阱**，
    %   本次一并对齐，避免以后有人踩。
    margin = d;
    max_coord = R + margin;
    n_max = ceil(max_coord / d) + 1;

    % 生成格点
    points = [];
    for i = -n_max:n_max
        for j = -n_max:n_max
            p = i * a1 + j * a2;
            r = norm(p);

            % 圆域裁剪
            if r <= R
                points = [points; p];
            end

            % Q4 外扩环带
            if extend_for_Q4 && r > R && r <= R + margin
                points = [points; p];
            end
        end
    end

    % 去重（欧氏距离 < 1e-6）
    P = unique(points, 'rows', 'stable');

    fprintf('[网格] d=%.1f m, 生成 %d 个检测点', d, size(P, 1));
    if extend_for_Q4
        fprintf(' (含 Q4 外扩环带)');
    end
    fprintf('\n');
end
